var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'carloc24',
applicationName: 'myapp',
appUid: 'h50W2wYJMHdl6zFBHv',
tenantUid: 'Fpb9yYC76HdDV5fDmx',
deploymentUid: 'ff102290-7475-49db-9fe1-fb92204762e2',
serviceName: 'apollo-lambda',
stageName: 'dev',
pluginVersion: '2.0.0'})
const handlerWrapperArgs = { functionName: 'apollo-lambda-dev-graphql', timeout: 6}
try {
  const userHandler = require('./graphql.js')
  module.exports.handler = serverlessSDK.handler(userHandler.graphqlHandler, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
