const { prisma } = require("./generated/prisma-client");

console.log(prisma);
